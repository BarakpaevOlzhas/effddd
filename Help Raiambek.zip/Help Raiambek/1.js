var express = require("express");
var bodyParser = require("body-parser");
var mongoose = require("mongoose");

var exp = express();
var unlecodedParser = bodyParser.urlencoded({extended : false});
mongoose.connect("mongodb://KakYgodno:titivi032312@ds163060.mlab.com:63060/datas", { useNewUrlParser: true });

var User = new mongoose.Schema({
  name:String
});

module.exports = mongoose.model('Users', User);


exp.get("/",function(req,res){
  res.sendFile(__dirname + "/1.html");
});

exp.post("/register",unlecodedParser,function(req,res){
  if(!req.body) return res.sendStatus(400);
    console.log(req.body.Name);

    var person = new User({ name: ""+req.body.Name });

     person.save();
});

exp.listen(3000);
